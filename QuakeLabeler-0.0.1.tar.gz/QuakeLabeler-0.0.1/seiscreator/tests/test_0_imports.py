
def test_import_seiscreator():
	import seiscreator
	from seiscreator import QueryArrival
	from seiscreator import SeisCreator
	from seiscreator import Interactive
	from seiscreator import CustomSamples